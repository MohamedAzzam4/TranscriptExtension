# Product backlog

This file preserves requested product ideas and their current implementation status.

## Implemented in extension 0.8.0

- Reorganized the word card into meanings, paired examples, combinations, grammar, and related-word sections. Empty dictionary sections are hidden.
- Added **Replay clip** using exact batch word timestamps or a clearly identified cue-based estimate. The original media time, pause state, and playback rate are restored.
- Added **YouGlish**, opening the selected word in the public German pronunciation route.
- Saved-word entries now retain context, definitions, examples, source video identity, and available audio timing.

- Added one-click UTF-8 text download of the most recent transcript.
- Completed transcripts are stored under stable platform/page identity plus audio language and restored automatically.
- Structured cues and optional word timestamps remain in storage; text is generated only for download.
- The popup lists saved transcripts and supports TXT export and deletion.
- The library is browser-local, capped at 20 records and roughly 7.5 MB, and excludes signed media URLs, headers, cookies, and secrets.

## Still deferred

- A larger searchable library page and an explicit **Open video** action for old transcripts.
- User-selected filesystem folders or companion-service persistence beyond browser storage.
- AI-generated B1 simplification or B2 tutoring. The current card deliberately uses only source-backed dictionary data.

## Acceptance notes

- All export and persistence actions must be understandable as a single user action.
- Reopening an already analyzed video must not run transcription again when a compatible complete transcript is available.
- Word-audio replay must not permanently seek, pause, or change the playback rate of the video.
- No signed media URLs, cookies, DRM material, or API secrets may be stored in the transcript library.
