importScripts("learning-features.js");

const ACTIVE_KEY = "activeExperiment";
const LAST_KEY = "lastExperimentId";
const SETTINGS_KEY = "experimentSettings";
const EXPERIMENT_PREFIX = "experiment:";
const DEFINITION_PREFIX = "definition:v3:de-en:";
const VOCABULARY_KEY = "savedVocabulary";
const TRANSLATION_SECRETS_KEY = "translationSecrets";
const TRANSCRIPT_LIBRARY_INDEX_KEY = "transcriptLibraryIndex";
const TRANSCRIPT_LIBRARY_LIMIT = 20;
const TRANSCRIPT_LIBRARY_BYTES_LIMIT = 7_500_000;
const NATIVE_HOST_NAME = "com.dub_transcript_lab.recognizer";
const learning = globalThis.DubTranscriptLearning;
const mediaClocks = new Map();
const runtimeSampleTimes = new Map();
const audioCoverageRanges = new Map();
const audioCoverageSaveTimes = new Map();
let nativeHostPort = null;
let nativeHostWaiter = null;
let batchNativeMessageQueue = Promise.resolve();

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender)
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});

chrome.tabs.onRemoved.addListener((tabId) => {
  void stopIfActiveTab(tabId);
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "loading") void stopIfActiveTab(tabId);
});

async function handleMessage(message, sender) {
  switch (message.type) {
    case "START_EXPERIMENT":
      return startSmartExperiment(message.settings);
    case "STOP_EXPERIMENT":
      await stopExperiment();
      return {};
    case "EXPORT_LAST_EXPERIMENT":
      return exportLastExperiment();
    case "EXPORT_LAST_TRANSCRIPT_TEXT":
      return exportLastTranscriptText();
    case "GET_TRANSCRIPT_LIBRARY":
      return getTranscriptLibrary();
    case "EXPORT_LIBRARY_TRANSCRIPT_TEXT":
      return exportLibraryTranscriptText(message.key);
    case "REMOVE_TRANSCRIPT_LIBRARY_ENTRY":
      return removeTranscriptLibraryEntry(message.key);
    case "PING_CONTENT":
      return {};
    case "CAPTION_SEGMENT":
      await appendCaption(sender.tab?.id, sender.frameId, message.segment);
      return {};
    case "MEDIA_EVENT":
      await handleMediaEvent(sender.tab?.id, sender.frameId, message.event);
      return {};
    case "MEDIA_CLOCK":
      await handleMediaClock(
        sender.tab?.id,
        sender.frameId,
        message.currentTime,
        message.playbackRate
      );
      return {};
    case "LOOKUP_WORD":
      return lookupBilingualWord(message.word);
    case "SAVE_WORD":
      return saveVocabularyWord(message.entry);
    case "REMOVE_SAVED_WORD":
      return removeSavedWord(message.word);
    case "GET_SAVED_WORDS":
      return getSavedWords();
    case "TRANSLATE_TEXT":
      return translateText(message);
    case "UPDATE_DISPLAY_SETTINGS":
      return updateDisplaySettings(message);
    case "SET_SYNC_OFFSET":
      return setSyncOffset(message.offset);
    case "OFFSCREEN_TRANSCRIPT":
      await replaceEpochTranscript(message);
      return {};
    case "OFFSCREEN_EPOCH_ANCHORED":
      await anchorEpoch(message);
      return {};
    case "OFFSCREEN_AUDIO_COVERAGE":
      await appendAudioCoverage(message);
      return {};
    case "OFFSCREEN_READY":
      await handleRecognizerReady();
      return {};
    case "OFFSCREEN_STATUS":
      await broadcastStatus(message.status, message.error);
      return {};
    default:
      return {};
  }
}

async function startSmartExperiment(settings) {
  settings = normalizeRuntimeSettings(settings);
  validateSettings(settings);
  const existing = await getActive();
  if (existing) await stopExperiment();

  const prepared = await prepareMediaTarget();
  const identity = learning.stableVideoIdentity(prepared.tab.url, settings.audioLanguage);
  const savedTranscript = await getStoredTranscript(identity);
  if (savedTranscript && isStoredTranscriptCompatible(savedTranscript, prepared.mediaTarget.context)) {
    return startLibraryExperiment(settings, prepared, savedTranscript);
  }
  const candidate = chooseBatchCandidate(prepared.tab, prepared.mediaTarget.context);
  if (candidate.supported) {
    return startBatchExperiment(settings, prepared, candidate);
  }
  return startLiveExperiment(settings, prepared, candidate.reason);
}

async function startLibraryExperiment(settings, prepared, savedTranscript) {
  const { tab, mediaTarget } = prepared;
  const context = mediaTarget.context;
  const id = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
  const experiment = createExperimentRecord(id, tab, context, settings, {
    requested: "auto",
    mode: "library",
    status: "complete",
    sourceKind: "local-library",
    sourceHost: null,
    fallbackReason: null,
    restoredFrom: savedTranscript.sourceExperimentId || null
  });
  experiment.asrSegments = sanitizeTranscriptSegments(savedTranscript.segments);
  const duration = Math.max(
    Number(savedTranscript.duration) || 0,
    Number(context.duration) || 0,
    experiment.asrSegments.reduce((maximum, segment) => Math.max(maximum, segment.end), 0)
  );
  const range = { start: 0, end: round(duration) };
  experiment.audioCoverage = [range];
  experiment.finishedAt = new Date().toISOString();
  const active = {
    experimentId: id,
    tabId: tab.id,
    mediaFrameId: mediaTarget.frameId,
    mode: "batch-ready",
    settings,
    syncOffset: normalizeSyncOffset(settings.syncOffset),
    replay: range,
    batchDuration: range.end,
    recognizerReady: true
  };

  await saveExperiment(experiment);
  await setActive(active);
  await sendToFrame(tab.id, mediaTarget.frameId, {
    type: "BEGIN_SESSION",
    experimentId: id,
    collectCaptions: false,
    syncOffset: active.syncOffset,
    captionPreferences: settings.captionPreferences,
    translationPreferences: settings.translationPreferences,
    audioLanguage: settings.audioLanguage,
    segments: experiment.asrSegments
  });
  await sendToActiveFrame(active, { type: "SET_REPLAY_MODE", enabled: true, range });
  const response = await sendToActiveFrame(active, { type: "CONTROL_MEDIA", action: "play" });
  await broadcastStatus(response?.ok
    ? "Saved transcript restored locally. Playback started without transcribing again."
    : "Saved transcript restored locally. Press play when you are ready.",
  response?.ok ? null : response?.error);
  return { experimentId: id, mode: "library", restored: true };
}

function isStoredTranscriptCompatible(record, context) {
  if (!Array.isArray(record?.segments) || !record.segments.length) return false;
  const savedDuration = Number(record.duration);
  const currentDuration = Number(context?.duration);
  if (!Number.isFinite(savedDuration) || !Number.isFinite(currentDuration)
    || savedDuration <= 0 || currentDuration <= 0) return true;
  return Math.abs(savedDuration - currentDuration) <= Math.max(3, currentDuration * 0.03);
}

async function prepareMediaTarget() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !tab.url?.startsWith("http")) {
    throw new Error("Open a normal web video tab before starting the experiment.");
  }
  const frameIds = await ensureContentScripts(tab.id);
  const mediaTarget = await findMediaTarget(tab.id, frameIds);
  if (!mediaTarget) {
    throw new Error(
      "No accessible HTML video was found in this tab or its player frames. "
      + "Start playback, reload the extension if it requested broader site access, then try again."
    );
  }
  const pauseResponse = await sendToFrame(tab.id, mediaTarget.frameId, {
    type: "CONTROL_MEDIA",
    action: "pause"
  });
  if (!pauseResponse?.ok) {
    throw new Error(pauseResponse?.error || "Could not pause the video while preparing.");
  }
  return { tab, mediaTarget };
}

async function startBatchExperiment(settings, prepared, candidate) {
  const { tab, mediaTarget } = prepared;
  const context = mediaTarget.context;
  const id = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
  const jobId = crypto.randomUUID();
  const experiment = createExperimentRecord(id, tab, context, settings, {
    requested: "auto",
    mode: "batch",
    status: "queued",
    sourceKind: candidate.sourceKind,
    sourceHost: safeHost(candidate.sourceUrl),
    fallbackReason: null
  });
  const active = {
    experimentId: id,
    tabId: tab.id,
    mediaFrameId: mediaTarget.frameId,
    mode: "batch-analyzing",
    batchJobId: jobId,
    settings,
    syncOffset: normalizeSyncOffset(settings.syncOffset),
    replay: null,
    recognizerReady: false
  };

  await saveExperiment(experiment);
  await setActive(active);
  await sendToFrame(tab.id, mediaTarget.frameId, {
    type: "BEGIN_SESSION",
    experimentId: id,
    collectCaptions: false,
    syncOffset: active.syncOffset,
    captionPreferences: settings.captionPreferences,
    translationPreferences: settings.translationPreferences,
    audioLanguage: settings.audioLanguage,
    segments: []
  });

  try {
    ensureNativeHostPort().postMessage({
      command: "batch_transcribe",
      jobId,
      sourceKind: candidate.sourceKind,
      sourceUrl: candidate.sourceUrl,
      headers: candidate.headers,
      durationHint: context.duration,
      language: settings.audioLanguage,
      captionLanguage: settings.captionLanguage,
      collectCaptions: settings.collectCaptions,
      model: settings.batchModel || "small"
    });
  } catch (error) {
    await fallbackBatchToLive(active, `Could not start full-video analysis: ${error.message}`);
    return { experimentId: id, mode: "live-fallback" };
  }

  await broadcastStatus("Full-video source found. Analyzing the audio locally before playback…");
  return { experimentId: id, mode: "batch" };
}

async function startLiveExperiment(settings, prepared, fallbackReason = null) {
  const { tab, mediaTarget } = prepared;
  await ensureRecognizerRunning(settings.serverUrl);
  await ensureOffscreenDocument();
  const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
  const context = mediaTarget.context;
  const id = `${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
  const epoch = createEpoch(context.currentTime, context.playbackRate, "start");
  const experiment = createExperimentRecord(id, tab, context, settings, {
    requested: "auto",
    mode: fallbackReason ? "live-fallback" : "live",
    status: "running",
    sourceKind: null,
    sourceHost: null,
    fallbackReason
  });
  experiment.epochs = [epoch];
  const active = {
    experimentId: id,
    tabId: tab.id,
    mediaFrameId: mediaTarget.frameId,
    mode: "live",
    settings,
    syncOffset: normalizeSyncOffset(settings.syncOffset),
    epoch,
    replay: null,
    recognizerReady: false
  };

  await saveExperiment(experiment);
  await setActive(active);
  audioCoverageRanges.set(id, []);
  audioCoverageSaveTimes.set(id, Date.now());

  await sendToFrame(tab.id, mediaTarget.frameId, {
    type: "BEGIN_SESSION",
    experimentId: id,
    collectCaptions: settings.collectCaptions,
    syncOffset: active.syncOffset,
    captionPreferences: settings.captionPreferences,
    translationPreferences: settings.translationPreferences,
    audioLanguage: settings.audioLanguage,
    segments: []
  });
  const captureResponse = await chrome.runtime.sendMessage({
    type: "OFFSCREEN_START",
    streamId,
    settings,
    epoch,
    playing: false,
    mediaClock: {
      currentTime: context.currentTime,
      playbackRate: context.playbackRate
    }
  });
  if (!captureResponse?.ok) {
    await stopExperiment();
    throw new Error(captureResponse?.error || "Tab capture failed.");
  }
  await broadcastStatus(fallbackReason
    ? `Full-video analysis is unavailable (${fallbackReason}). Preparing live transcription automatically.`
    : "Preparing recognizer. The video will start automatically when ready.");
  return { experimentId: id, mode: fallbackReason ? "live-fallback" : "live" };
}

function createExperimentRecord(id, tab, context, settings, pipeline) {
  return {
    schemaVersion: 4,
    id,
    createdAt: new Date().toISOString(),
    finishedAt: null,
    platform: identifyPlatform(tab.url),
    page: {
      title: tab.title || "Untitled video",
      url: tab.url,
      videoIdentity: learning.stableVideoIdentity(tab.url, settings.audioLanguage),
      playerFrameUrl: context.frameUrl || tab.url,
      duration: context.duration
    },
    audioLanguage: settings.audioLanguage,
    captionLanguage: settings.captionLanguage,
    captionsUsedAsInput: false,
    settings: {
      collectCaptions: settings.collectCaptions,
      serverUrl: settings.serverUrl,
      batchModel: settings.batchModel || "small",
      syncOffset: normalizeSyncOffset(settings.syncOffset),
      captionPreferences: settings.captionPreferences,
      translationPreferences: settings.translationPreferences
    },
    pipeline,
    epochs: [],
    asrSegments: [],
    captionSegments: [],
    evaluation: null,
    audioCoverage: [],
    runtimeSamples: []
  };
}

function chooseBatchCandidate(tab, context) {
  if (context.drmProtected) {
    return { supported: false, reason: "the player reported encrypted media" };
  }
  if (identifyPlatform(tab.url) === "youtube") {
    return {
      supported: true,
      sourceKind: "youtube",
      sourceUrl: tab.url,
      headers: {}
    };
  }
  const sourceUrl = (context.batchCandidates || [])
    .find((url) => /^https?:\/\//i.test(url));
  if (!sourceUrl) {
    return {
      supported: false,
      reason: context.sourceKind === "blob"
        ? "the player exposes only a blob stream"
        : "no accessible HTTP media source was detected"
    };
  }
  const headers = {
    "user-agent": context.userAgent || "",
    referer: context.frameUrl || context.frameReferrer || tab.url
  };
  try {
    headers.origin = new URL(context.frameUrl || tab.url).origin;
  } catch {
    // Referer and user agent are sufficient when the frame URL is unusual.
  }
  return { supported: true, sourceKind: "direct", sourceUrl, headers };
}

function safeHost(value) {
  try {
    return new URL(value).hostname;
  } catch {
    return null;
  }
}

async function ensureRecognizerRunning(serverUrl) {
  const url = new URL(serverUrl);
  if (url.hostname !== "127.0.0.1" || url.port !== "8000") {
    throw new Error("Automatic startup currently requires ws://127.0.0.1:8000/asr.");
  }
  if (nativeHostWaiter) return nativeHostWaiter.promise;

  const port = ensureNativeHostPort();

  let resolveWaiter;
  let rejectWaiter;
  const promise = new Promise((resolve, reject) => {
    resolveWaiter = resolve;
    rejectWaiter = reject;
  });
  const timeout = setTimeout(() => {
    rejectNativeHostWaiter("The local recognizer did not become ready within 10 minutes.");
  }, 10 * 60_000);
  nativeHostWaiter = { promise, resolve: resolveWaiter, reject: rejectWaiter, timeout };

  try {
    port.postMessage({ command: "ensure_running" });
  } catch (error) {
    rejectNativeHostWaiter(error.message);
  }
  return promise;
}

function ensureNativeHostPort() {
  if (!nativeHostPort) {
    nativeHostPort = chrome.runtime.connectNative(NATIVE_HOST_NAME);
    nativeHostPort.onMessage.addListener(handleNativeHostMessage);
    nativeHostPort.onDisconnect.addListener(handleNativeHostDisconnect);
  }
  return nativeHostPort;
}

function handleNativeHostMessage(message) {
  if (message?.state?.startsWith("batch_")) {
    batchNativeMessageQueue = batchNativeMessageQueue
      .then(() => handleBatchNativeMessage(message))
      .catch(async (error) => {
        console.error("Failed to process an ordered batch message", error);
        await fallbackActiveBatch(`the extension could not assemble the transcript: ${error.message}`);
      });
    return;
  }
  if (message?.state === "starting") {
    void broadcastStatus("Starting the local recognizer automatically…");
    return;
  }
  if (message?.state === "ready") {
    const waiter = nativeHostWaiter;
    nativeHostWaiter = null;
    if (!waiter) return;
    clearTimeout(waiter.timeout);
    waiter.resolve();
    return;
  }
  if (message?.state === "error") {
    rejectNativeHostWaiter(message.message || "The native recognizer host reported an error.");
    void fallbackActiveBatch(message.message || "the native batch host reported an error");
  }
}

function handleNativeHostDisconnect() {
  const error = chrome.runtime.lastError?.message
    || "The local recognizer launcher disconnected.";
  nativeHostPort = null;
  rejectNativeHostWaiter(error);
  void fallbackActiveBatch(error);
}

function rejectNativeHostWaiter(error) {
  const waiter = nativeHostWaiter;
  nativeHostWaiter = null;
  if (!waiter) return;
  clearTimeout(waiter.timeout);
  waiter.reject(new Error(error));
}

async function handleBatchNativeMessage(message) {
  const active = await getActive();
  if (
    !active
    || active.mode !== "batch-analyzing"
    || active.batchJobId !== message.jobId
  ) return;

  if (message.state === "batch_queued") {
    await broadcastStatus("Full-video analysis queued locally.");
    return;
  }
  if (message.state === "batch_status") {
    await broadcastStatus(message.message || "Preparing full-video analysis locally.");
    return;
  }
  if (message.state === "batch_started") {
    const experiment = await getExperiment(active.experimentId);
    if (experiment) {
      experiment.pipeline.status = "transcribing";
      experiment.pipeline.duration = Number(message.duration) || experiment.page.duration;
      experiment.pipeline.decodeProgress = 100;
      experiment.pipeline.decodedSeconds = experiment.pipeline.duration;
      experiment.pipeline.title = message.title || null;
      await saveExperiment(experiment);
    }
    await broadcastStatus("Audio decoded. Transcribing the complete video locally…");
    return;
  }
  if (message.state === "batch_download_progress") {
    const percent = Number(message.percent);
    const downloadedBytes = Math.max(0, Number(message.downloadedBytes) || 0);
    const bytesPerSecond = Math.max(0, Number(message.bytesPerSecond) || 0);
    const experiment = await getExperiment(active.experimentId);
    if (experiment) {
      experiment.pipeline.status = "downloading-audio";
      experiment.pipeline.downloadProgress = Number.isFinite(percent) ? percent : null;
      experiment.pipeline.downloadedBytes = downloadedBytes;
      experiment.pipeline.downloadBytesPerSecond = bytesPerSecond || null;
      await saveExperiment(experiment);
    }
    const speed = bytesPerSecond ? ` (${formatTransferRate(bytesPerSecond)})` : "";
    await broadcastStatus(Number.isFinite(percent)
      ? `Downloading the audio locally… ${Math.max(0, Math.min(100, percent))}%${speed}`
      : `Downloading the audio locally… ${formatMegabytes(downloadedBytes)} received${speed}`);
    return;
  }
  if (message.state === "batch_decode_progress") {
    const percent = Number(message.percent);
    const decodedSeconds = Math.max(0, Number(message.decodedSeconds) || 0);
    const experiment = await getExperiment(active.experimentId);
    if (experiment) {
      experiment.pipeline.status = "decoding";
      experiment.pipeline.decodeProgress = Number.isFinite(percent) ? percent : null;
      experiment.pipeline.decodedSeconds = round(decodedSeconds);
      await saveExperiment(experiment);
    }
    await broadcastStatus(Number.isFinite(percent)
      ? `Decoding the full audio locally… ${Math.max(0, Math.min(99, percent))}%`
      : `Decoding the full audio locally… ${formatClock(decodedSeconds)} processed`);
    return;
  }
  if (message.state === "batch_progress") {
    const percent = Math.max(0, Math.min(99, Number(message.percent) || 0));
    const experiment = await getExperiment(active.experimentId);
    if (experiment) {
      experiment.pipeline.status = "transcribing";
      experiment.pipeline.progress = percent;
      await saveExperiment(experiment);
    }
    await broadcastStatus(`Transcribing the complete video locally… ${percent}%`);
    return;
  }
  if (message.state === "batch_segments") {
    const experiment = await getExperiment(active.experimentId);
    if (!experiment) return;
    const byId = new Map(experiment.asrSegments.map((segment) => [segment.id, segment]));
    for (const segment of message.segments || []) byId.set(segment.id, segment);
    experiment.asrSegments = [...byId.values()]
      .sort((a, b) => a.start - b.start || a.end - b.end);
    await saveExperiment(experiment);
    return;
  }
  if (message.state === "batch_captions") {
    const experiment = await getExperiment(active.experimentId);
    if (!experiment) return;
    const byId = new Map(experiment.captionSegments.map((segment) => [segment.id, segment]));
    for (const segment of message.segments || []) byId.set(segment.id, segment);
    experiment.captionSegments = [...byId.values()]
      .sort((a, b) => a.start - b.start || a.end - b.end);
    await saveExperiment(experiment);
    return;
  }
  if (message.state === "batch_complete") {
    await completeBatchExperiment(active, message);
    return;
  }
  if (message.state === "batch_error") {
    await fallbackBatchToLive(active, message.message || "the media source could not be analyzed");
  }
}

async function completeBatchExperiment(active, message) {
  const latest = await getActive();
  if (!latest || latest.batchJobId !== active.batchJobId || latest.mode !== "batch-analyzing") return;
  const experiment = await getExperiment(latest.experimentId);
  if (!experiment) return;
  const expectedSegmentCount = Number(message.segmentCount);
  if (
    Number.isInteger(expectedSegmentCount)
    && expectedSegmentCount >= 0
    && experiment.asrSegments.length !== expectedSegmentCount
  ) {
    throw new Error(
      `received ${experiment.asrSegments.length} of ${expectedSegmentCount} transcript segments`
    );
  }
  const expectedCaptionCount = Number(message.captionSegmentCount);
  if (
    Number.isInteger(expectedCaptionCount)
    && expectedCaptionCount >= 0
    && experiment.captionSegments.length !== expectedCaptionCount
  ) {
    throw new Error(
      `received ${experiment.captionSegments.length} of ${expectedCaptionCount} answer-key segments`
    );
  }
  const lastCueEnd = experiment.asrSegments.reduce(
    (maximum, segment) => Math.max(maximum, Number(segment.end) || 0),
    0
  );
  const duration = Math.max(
    Number(message.duration) || 0,
    Number(experiment.page.duration) || 0,
    lastCueEnd
  );
  const range = { start: 0, end: round(duration) };
  experiment.audioCoverage = [range];
  experiment.pipeline = {
    ...experiment.pipeline,
    status: "complete",
    progress: 100,
    duration: range.end,
    language: message.language || experiment.audioLanguage,
    device: message.device || null,
    segmentCount: experiment.asrSegments.length,
    completedAt: new Date().toISOString()
  };
  experiment.evaluation = message.evaluation || null;
  await saveExperiment(experiment);
  await trySaveTranscriptToLibrary(experiment);
  audioCoverageRanges.set(experiment.id, [range]);

  latest.mode = "batch-ready";
  latest.replay = range;
  latest.batchDuration = range.end;
  await setActive(latest);
  await sendToActiveFrame(latest, {
    type: "TRANSCRIPT_UPDATE",
    segments: experiment.asrSegments,
    buffer: "",
    remainingTimeTranscription: 0,
    processingLag: 0,
    stabilizationDelay: 0
  });
  await sendToActiveFrame(latest, { type: "SET_REPLAY_MODE", enabled: true, range });
  if (latest.settings.collectCaptions && experiment.captionSegments.length === 0) {
    await sendToActiveFrame(latest, { type: "SET_CAPTION_COLLECTION", enabled: true });
  }
  const response = await sendToActiveFrame(latest, { type: "CONTROL_MEDIA", action: "play" });
  const evaluationSuffix = formatEvaluationSummary(experiment.evaluation);
  await broadcastStatus(response?.ok
    ? `Full transcript ready. Playback started from cached batch data.${evaluationSuffix}`
    : `Full transcript ready. Press play when you are ready.${evaluationSuffix}`,
  response?.ok ? null : response?.error);
}

async function fallbackActiveBatch(error) {
  const active = await getActive();
  if (active?.mode === "batch-analyzing") await fallbackBatchToLive(active, error);
}

async function fallbackBatchToLive(active, reason) {
  const latest = await getActive();
  if (!latest || latest.mode !== "batch-analyzing" || latest.batchJobId !== active.batchJobId) return;
  const contextResponse = await sendToActiveFrame(latest, { type: "GET_MEDIA_CONTEXT" });
  if (!contextResponse?.ok || !contextResponse.context) {
    await broadcastStatus(null, `Full-video analysis failed and live fallback could not inspect the player: ${reason}`);
    return;
  }

  const experiment = await getExperiment(latest.experimentId);
  if (!experiment) return;
  const context = contextResponse.context;
  const epoch = createEpoch(context.currentTime, context.playbackRate, "batch-fallback");
  experiment.asrSegments = [];
  experiment.audioCoverage = [];
  experiment.epochs = [epoch];
  experiment.pipeline = {
    ...experiment.pipeline,
    mode: "live-fallback",
    status: "preparing-live",
    fallbackReason: reason,
    progress: null
  };
  latest.mode = "live";
  latest.epoch = epoch;
  latest.replay = null;
  latest.recognizerReady = false;
  delete latest.batchJobId;
  await saveExperiment(experiment);
  await setActive(latest);
  audioCoverageRanges.set(experiment.id, []);
  audioCoverageSaveTimes.set(experiment.id, Date.now());
  await sendToActiveFrame(latest, {
    type: "TRANSCRIPT_UPDATE",
    segments: [],
    buffer: ""
  });
  await sendToActiveFrame(latest, {
    type: "SET_CAPTION_COLLECTION",
    enabled: latest.settings.collectCaptions
  });
  await sendToActiveFrame(latest, { type: "SET_REPLAY_MODE", enabled: false });
  await broadcastStatus(`Full-video analysis was unavailable (${reason}). Starting live transcription automatically…`);

  try {
    await ensureRecognizerRunning(latest.settings.serverUrl);
    await ensureOffscreenDocument();
    const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: latest.tabId });
    const captureResponse = await chrome.runtime.sendMessage({
      type: "OFFSCREEN_START",
      streamId,
      settings: latest.settings,
      epoch,
      playing: false,
      mediaClock: {
        currentTime: context.currentTime,
        playbackRate: context.playbackRate
      }
    });
    if (!captureResponse?.ok) throw new Error(captureResponse?.error || "Tab capture failed.");
  } catch (error) {
    experiment.pipeline.status = "error";
    experiment.pipeline.fallbackError = error.message;
    await saveExperiment(experiment);
    await broadcastStatus(null, `Both full-video and live transcription failed: ${error.message}`);
  }
}

async function handleRecognizerReady() {
  const active = await getActive();
  if (!active || !isLiveMode(active) || active.recognizerReady) return;

  active.recognizerReady = true;
  await setActive(active);
  const response = await sendToActiveFrame(active, {
    type: "CONTROL_MEDIA",
    action: "play"
  });
  if (response?.ok) {
    await broadcastStatus("Recognizer ready. Playback started automatically.");
  } else {
    await broadcastStatus("Recognizer ready. Press play to begin.", response?.error || null);
  }
}

async function stopExperiment() {
  const active = await getActive();
  if (!active) return;

  const wasLive = isLiveMode(active);
  const batchJobId = active.mode === "batch-analyzing" ? active.batchJobId : null;
  active.mode = "stopping";
  await setActive(active);
  await sendToActiveFrame(active, { type: "END_SESSION" });
  if (batchJobId && nativeHostPort) {
    try { nativeHostPort.postMessage({ command: "cancel_batch", jobId: batchJobId }); } catch { }
  }
  if (wasLive) {
    await sendToOffscreen({ type: "OFFSCREEN_STOP" });
    await persistAudioCoverage(active, true);
  }

  const experiment = await getExperiment(active.experimentId);
  if (experiment) {
    experiment.finishedAt = new Date().toISOString();
    await saveExperiment(experiment);
    if (wasLive && hasCompleteLiveCoverage(experiment)) {
      await trySaveTranscriptToLibrary(experiment);
    }
  }
  await chrome.storage.session.remove(ACTIVE_KEY);
  mediaClocks.delete(active.tabId);
  runtimeSampleTimes.delete(active.experimentId);
  audioCoverageRanges.delete(active.experimentId);
  audioCoverageSaveTimes.delete(active.experimentId);
  await broadcastStatus("Experiment stopped and cached locally.");
}

async function stopIfActiveTab(tabId) {
  const active = await getActive();
  if (active?.tabId === tabId) await stopExperiment();
}

async function replaceEpochTranscript(message) {
  const active = await getActive();
  if (!active || active.epoch?.id !== message.epochId) return;
  const experiment = await getExperiment(active.experimentId);
  if (!experiment) return;

  const incomingSegments = message.segments || [];
  let retainedSegments = experiment.asrSegments
    .filter((segment) => segment.epochId !== message.epochId);
  if (incomingSegments.length) {
    const replacementStart = Math.min(...incomingSegments.map((segment) => segment.start));
    const replacementEnd = Math.max(...incomingSegments.map((segment) => segment.end));
    retainedSegments = retainedSegments.filter((segment) => (
      segment.end <= replacementStart + 0.05
      || segment.start >= replacementEnd - 0.05
    ));
  }

  experiment.asrSegments = retainedSegments
    .concat(incomingSegments)
    .sort((a, b) => a.start - b.start || a.end - b.end);
  const now = Date.now();
  const lastSample = runtimeSampleTimes.get(active.experimentId) || 0;
  if (now - lastSample >= 1000) {
    const clock = mediaClocks.get(active.tabId);
    experiment.runtimeSamples ||= [];
    experiment.runtimeSamples.push({
      observedAt: new Date(now).toISOString(),
      epochId: message.epochId,
      mediaTime: clock?.currentTime ?? null,
      remainingTimeTranscription: message.remainingTimeTranscription,
      processingLag: message.processingLag,
      stabilizationDelay: message.stabilizationDelay,
      committedSegmentCount: message.segments.length,
      hasLiveBuffer: Boolean(message.buffer)
    });
    runtimeSampleTimes.set(active.experimentId, now);
  }
  await saveExperiment(experiment);
  await sendToActiveFrame(active, {
    type: "TRANSCRIPT_UPDATE",
    segments: experiment.asrSegments,
    buffer: message.buffer,
    remainingTimeTranscription: message.remainingTimeTranscription,
    processingLag: message.processingLag,
    stabilizationDelay: message.stabilizationDelay
  });
}

async function anchorEpoch(message) {
  const active = await getActive();
  if (!active || active.epoch?.id !== message.epochId) return;

  active.epoch = {
    ...active.epoch,
    mediaStart: round(message.mediaStart),
    playbackRate: Number(message.playbackRate) || 1,
    anchored: true,
    anchoredAt: new Date().toISOString()
  };
  await setActive(active);

  const experiment = await getExperiment(active.experimentId);
  if (!experiment) return;
  experiment.epochs = experiment.epochs.map((epoch) => (
    epoch.id === message.epochId ? active.epoch : epoch
  ));
  await saveExperiment(experiment);
}

async function appendAudioCoverage(message) {
  const active = await getActive();
  if (!active || active.epoch?.id !== message.epochId) return;
  const start = Number(message.start);
  const end = Number(message.end);
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) return;

  let ranges = audioCoverageRanges.get(active.experimentId);
  if (!ranges) {
    const experiment = await getExperiment(active.experimentId);
    ranges = experiment?.audioCoverage || [];
  }
  ranges = mergeCoverageRanges(ranges.concat({ start: round(start), end: round(end) }));
  audioCoverageRanges.set(active.experimentId, ranges);
  await persistAudioCoverage(active, false);
}

async function persistAudioCoverage(active, force) {
  const ranges = audioCoverageRanges.get(active.experimentId);
  if (!ranges) return;
  const now = Date.now();
  const lastSave = audioCoverageSaveTimes.get(active.experimentId) || 0;
  if (!force && now - lastSave < 2_000) return;

  const experiment = await getExperiment(active.experimentId);
  if (!experiment) return;
  experiment.audioCoverage = ranges;
  await saveExperiment(experiment);
  audioCoverageSaveTimes.set(active.experimentId, now);
}

async function appendCaption(tabId, frameId, segment) {
  const active = await getActive();
  if (!isActiveMediaFrame(active, tabId, frameId) || !segment?.text) return;
  const experiment = await getExperiment(active.experimentId);
  if (!experiment) return;

  const previous = experiment.captionSegments.at(-1);
  const duplicate = previous
    && previous.text === segment.text
    && Math.abs(previous.start - segment.start) < 0.25;
  if (!duplicate) {
    experiment.captionSegments.push({
      id: crypto.randomUUID(),
      start: round(segment.start),
      end: round(Math.max(segment.start, segment.end)),
      text: String(segment.text).trim(),
      source: segment.source || "visible-caption"
    });
    await saveExperiment(experiment);
  }
}

async function handleMediaEvent(tabId, frameId, event) {
  const active = await getActive();
  if (!isActiveMediaFrame(active, tabId, frameId)) return;

  if (event.name === "play" || event.name === "pause") {
    if (active.mode === "batch-analyzing") {
      if (event.name === "play") {
        await sendToActiveFrame(active, { type: "CONTROL_MEDIA", action: "pause" });
        await broadcastStatus("Full-video analysis is still running; playback will start when it is ready.");
      }
      return;
    }
    if (!isLiveMode(active)) return;
    await sendToOffscreen({
      type: "OFFSCREEN_SET_PLAYING",
      playing: event.name === "play"
    });
    return;
  }

  if (event.name === "seeking") {
    if (isLiveMode(active)) {
      await sendToOffscreen({ type: "OFFSCREEN_SET_CAPTURE_ENABLED", enabled: false });
    }
    return;
  }

  if (event.name === "seeked") {
    await handleSeek(active, event.currentTime, event.playbackRate);
  } else if (event.name === "ratechange" && isLiveMode(active)) {
    await beginEpoch(active, event.currentTime, event.playbackRate, "ratechange");
  }
}

async function handleSeek(active, currentTime, playbackRate) {
  if (active.mode === "batch-analyzing" || active.mode === "stopping") return;
  const experiment = await getExperiment(active.experimentId);
  const coverage = audioCoverageRanges.get(active.experimentId)
    || experiment?.audioCoverage
    || [];
  const range = findCoveredRange(coverage, experiment?.asrSegments || [], currentTime);
  if (range) {
    active.replay = range;
    await setActive(active);
    if (isLiveMode(active)) {
      await sendToOffscreen({ type: "OFFSCREEN_SET_CAPTURE_ENABLED", enabled: false });
    }
    await sendToActiveFrame(active, { type: "SET_REPLAY_MODE", enabled: true, range });
    return;
  }
  if (active.mode === "batch-ready") return;
  await beginEpoch(active, currentTime, playbackRate, "seek");
}

async function handleMediaClock(tabId, frameId, currentTime, playbackRate) {
  const active = await getActive();
  if (!isActiveMediaFrame(active, tabId, frameId)) return;
  mediaClocks.set(tabId, { currentTime, playbackRate });
  if (isLiveMode(active)) {
    await sendToOffscreen({
      type: "OFFSCREEN_MEDIA_CLOCK",
      currentTime,
      playbackRate
    });
  }
  if (active.mode === "batch-ready" || active.mode === "batch-analyzing") return;
  if (!active.replay) return;
  const outsideReplay = currentTime < active.replay.start - 0.5
    || currentTime >= active.replay.end - 0.15;
  if (outsideReplay) await beginEpoch(active, currentTime, playbackRate, "after-cached-replay");
}

async function beginEpoch(active, currentTime, playbackRate, reason) {
  if (!isLiveMode(active)) return;
  const epoch = createEpoch(currentTime, playbackRate, reason);
  active.epoch = epoch;
  active.replay = null;
  await setActive(active);

  const experiment = await getExperiment(active.experimentId);
  if (experiment) {
    experiment.epochs.push(epoch);
    await saveExperiment(experiment);
  }

  await sendToActiveFrame(active, { type: "SET_REPLAY_MODE", enabled: false });
  await sendToOffscreen({ type: "OFFSCREEN_RESET_EPOCH", epoch });
}

function findCoveredRange(audioCoverage, segments, currentTime) {
  const explicitCoverage = mergeCoverageRanges(audioCoverage || []);
  const inferredCoverage = coverageFromSegments(segments || []);
  const ranges = explicitCoverage.length
    ? mergeCoverageRanges(explicitCoverage.concat(inferredCoverage))
    : inferredCoverage;
  return ranges.find((range) => (
    currentTime >= range.start - 0.4
    && currentTime < range.end + 0.1
  )) || null;
}

function coverageFromSegments(segments) {
  if (!segments.length) return [];
  return mergeCoverageRanges(segments.map((segment) => ({
    start: segment.start,
    end: segment.end
  })), 3);
}

function mergeCoverageRanges(ranges, gapTolerance = 0.75) {
  const sorted = ranges
    .map((range) => ({ start: Number(range.start), end: Number(range.end) }))
    .filter((range) => (
      Number.isFinite(range.start)
      && Number.isFinite(range.end)
      && range.end > range.start
    ))
    .sort((a, b) => a.start - b.start || a.end - b.end);
  const merged = [];
  for (const segment of sorted) {
    const previous = merged.at(-1);
    if (previous && segment.start <= previous.end + gapTolerance) {
      previous.end = Math.max(previous.end, segment.end);
    } else {
      merged.push({ start: segment.start, end: segment.end });
    }
  }
  return merged.map((range) => ({ start: round(range.start), end: round(range.end) }));
}

async function exportLastExperiment() {
  const stored = await chrome.storage.local.get(LAST_KEY);
  const id = stored[LAST_KEY];
  if (!id) throw new Error("Run an experiment before exporting.");
  const experiment = await getExperiment(id);
  if (!experiment) throw new Error("The last experiment is no longer in local storage.");
  const title = experiment.page.title.replace(/[^a-z0-9_-]+/gi, "-").slice(0, 60) || "video";
  return {
    experiment,
    filename: `dub-transcript-lab/${title}-${id}.json`
  };
}

async function exportLastTranscriptText() {
  const stored = await chrome.storage.local.get(LAST_KEY);
  const id = stored[LAST_KEY];
  if (!id) throw new Error("Analyze a video before downloading its transcript.");
  const experiment = await getExperiment(id);
  if (!experiment?.asrSegments?.length) {
    throw new Error("The last experiment does not contain a transcript yet.");
  }
  return transcriptTextExport(experiment);
}

async function exportLibraryTranscriptText(key) {
  const record = await getTranscriptLibraryRecord(key);
  if (!record) throw new Error("That saved transcript is no longer available.");
  return transcriptTextExport(record);
}

function transcriptTextExport(record) {
  const title = record.title || record.page?.title || "video";
  const language = record.audioLanguage || "unknown";
  return {
    text: learning.transcriptToText(record),
    filename: `dub-transcript-lab/transcripts/${learning.safeFilename(title)}-${language}.txt`
  };
}

async function setSyncOffset(rawOffset) {
  const syncOffset = normalizeSyncOffset(rawOffset);
  const active = await getActive();
  if (!active) return { syncOffset };

  active.syncOffset = syncOffset;
  active.settings = { ...active.settings, syncOffset };
  await setActive(active);
  const experiment = await getExperiment(active.experimentId);
  if (experiment) {
    experiment.settings ||= {};
    experiment.settings.syncOffset = syncOffset;
    await saveExperiment(experiment);
  }
  await sendToActiveFrame(active, { type: "SET_SYNC_OFFSET", offset: syncOffset });
  return { syncOffset };
}

async function updateDisplaySettings(message) {
  const captionPreferences = learning.normalizeCaptionPreferences(message.captionPreferences);
  const translationPreferences = learning.normalizeTranslationPreferences(
    message.translationPreferences
  );
  const storedSettings = await chrome.storage.local.get(SETTINGS_KEY);
  await chrome.storage.local.set({
    [SETTINGS_KEY]: {
      ...(storedSettings[SETTINGS_KEY] || {}),
      captionPreferences,
      translationPreferences
    }
  });
  const active = await getActive();
  if (!active) return { captionPreferences, translationPreferences };

  active.settings = {
    ...active.settings,
    captionPreferences,
    translationPreferences
  };
  await setActive(active);
  const experiment = await getExperiment(active.experimentId);
  if (experiment) {
    experiment.settings ||= {};
    experiment.settings.captionPreferences = captionPreferences;
    experiment.settings.translationPreferences = translationPreferences;
    await saveExperiment(experiment);
  }
  await sendToActiveFrame(active, {
    type: "APPLY_DISPLAY_SETTINGS",
    captionPreferences,
    translationPreferences,
    resetTranslationCache: Boolean(message.resetTranslationCache)
  });
  return { captionPreferences, translationPreferences };
}

async function translateText(message) {
  const text = String(message.text || "").replace(/\s+/g, " ").trim().slice(0, 2_000);
  if (!text) return { translatedText: "", provider: "none" };
  const sourceLanguage = String(message.sourceLanguage || "de").slice(0, 16).toLowerCase();
  const preferences = learning.normalizeTranslationPreferences(message.translationPreferences);
  const targetLanguage = preferences.targetLanguage;
  if (sourceLanguage === targetLanguage) return { translatedText: text, provider: "identity" };

  const cacheKey = learning.translationCacheKey(text, sourceLanguage, targetLanguage);
  const cached = await chrome.storage.local.get(cacheKey);
  if (cached[cacheKey]?.sourceText === text && cached[cacheKey]?.translatedText) {
    return cached[cacheKey];
  }

  let browserError = null;
  if (preferences.provider !== "google") {
    try {
      await ensureOffscreenDocument();
      const response = await sendToOffscreen({
        type: "OFFSCREEN_TRANSLATE_TEXT",
        text,
        sourceLanguage,
        targetLanguage
      });
      if (!response?.ok || !response.translatedText) {
        throw new Error(response?.error || "The browser Translator API is unavailable.");
      }
      const result = {
        sourceText: text,
        translatedText: String(response.translatedText),
        provider: "browser",
        translatedAt: new Date().toISOString()
      };
      await chrome.storage.local.set({ [cacheKey]: result });
      return result;
    } catch (error) {
      browserError = error;
      if (preferences.provider === "browser") throw error;
    }
  }

  const stored = await chrome.storage.local.get(TRANSLATION_SECRETS_KEY);
  const apiKey = String(stored[TRANSLATION_SECRETS_KEY]?.googleApiKey || "").trim();
  if (!apiKey) {
    throw new Error(
      browserError?.message
        ? `On-device translation is unavailable (${browserError.message}). Add an optional Google Cloud Translation API key in the extension settings.`
        : "Add a Google Cloud Translation API key in the extension settings."
    );
  }

  const response = await fetch(
    `https://translation.googleapis.com/language/translate/v2?key=${encodeURIComponent(apiKey)}`,
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        q: text,
        source: sourceLanguage,
        target: targetLanguage,
        format: "text"
      })
    }
  );
  if (!response.ok) {
    const payload = await response.json().catch(() => null);
    throw new Error(
      payload?.error?.message || `Google Cloud Translation returned HTTP ${response.status}.`
    );
  }
  const payload = await response.json();
  const translatedText = learning.htmlToPlainText(
    payload?.data?.translations?.[0]?.translatedText
  );
  if (!translatedText) throw new Error("Google Cloud Translation returned no text.");
  const result = {
    sourceText: text,
    translatedText,
    provider: "google",
    translatedAt: new Date().toISOString()
  };
  await chrome.storage.local.set({ [cacheKey]: result });
  return result;
}

async function lookupBilingualWord(rawWord) {
  const word = learning.sanitizeWord(rawWord);
  if (!word) throw new Error("Select a German word first.");

  const normalized = learning.normalizedWord(word);
  const cacheKey = `${DEFINITION_PREFIX}${normalized}`;
  const cached = await chrome.storage.local.get(cacheKey);
  if (cached[cacheKey]) {
    return { ...cached[cacheKey], saved: await isVocabularyWordSaved(normalized) };
  }

  const [germanResult, englishResult] = await Promise.allSettled([
    fetchGermanWiktionaryEntry(word),
    fetchEnglishWiktionaryEntry(word)
  ]);
  if (germanResult.status === "rejected" && englishResult.status === "rejected") {
    throw new Error(
      `Both Wiktionary lookups failed (${germanResult.reason?.message || "German lookup"}; `
      + `${englishResult.reason?.message || "English lookup"}).`
    );
  }

  const german = germanResult.status === "fulfilled" ? germanResult.value : {};
  const english = englishResult.status === "fulfilled" ? englishResult.value : {};
  const title = german.title || word;
  const examples = deduplicateExamples([
    ...(german.examples || []),
    ...(english.examples || [])
  ]);
  const result = {
    word,
    title,
    germanDefinition: german.germanDefinition || null,
    englishDefinition: english.englishDefinition || null,
    germanDefinitions: german.germanDefinitions || [],
    englishDefinitions: english.englishDefinitions || [],
    example: examples[0]?.german || english.example || null,
    exampleTranslation: examples[0]?.english || english.exampleTranslation || null,
    examples,
    collocations: german.collocations || [],
    synonyms: german.synonyms || [],
    domains: german.domains || [],
    grammar: german.grammar || null,
    wordType: german.wordType || english.partOfSpeech || null,
    pronunciation: german.pronunciation || null,
    germanSourceUrl: `https://de.wiktionary.org/wiki/${encodeURIComponent(title)}`,
    englishSourceUrl: `https://en.wiktionary.org/wiki/${encodeURIComponent(word)}`,
    fetchedAt: new Date().toISOString()
  };
  await chrome.storage.local.set({ [cacheKey]: result });
  return { ...result, saved: await isVocabularyWordSaved(normalized) };
}

async function fetchGermanWiktionaryEntry(word) {
  const url = new URL("https://de.wiktionary.org/w/api.php");
  url.search = new URLSearchParams({
    action: "parse",
    page: word,
    prop: "text",
    format: "json",
    formatversion: "2",
    origin: "*"
  }).toString();

  const response = await fetch(url, { method: "GET" });
  if (!response.ok) throw new Error(`German Wiktionary returned HTTP ${response.status}.`);
  const payload = await response.json();
  const title = payload.parse?.title || word;
  return {
    title,
    ...learning.extractGermanWiktionaryEntry(payload.parse?.text)
  };
}

async function fetchEnglishWiktionaryEntry(word) {
  const url = `https://en.wiktionary.org/api/rest_v1/page/definition/${encodeURIComponent(word)}`;
  const response = await fetch(url, { method: "GET" });
  if (!response.ok) throw new Error(`English Wiktionary returned HTTP ${response.status}.`);
  return learning.extractEnglishWiktionaryEntry(await response.json());
}

function deduplicateExamples(values) {
  const seen = new Set();
  return values.filter((example) => {
    const german = String(example?.german || "").trim();
    if (!german) return false;
    const key = german.toLocaleLowerCase("de");
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 4);
}

async function getSavedWords() {
  const stored = await chrome.storage.local.get(VOCABULARY_KEY);
  const entries = Array.isArray(stored[VOCABULARY_KEY]) ? stored[VOCABULARY_KEY] : [];
  return {
    entries: entries
      .map((entry) => learning.normalizeVocabularyEntry(entry))
      .filter(Boolean)
      .sort((a, b) => b.savedAt.localeCompare(a.savedAt))
  };
}

async function saveVocabularyWord(rawEntry) {
  const active = await getActive();
  const experiment = active ? await getExperiment(active.experimentId) : null;
  const entry = learning.normalizeVocabularyEntry({
    ...rawEntry,
    video: rawEntry?.video || (experiment?.page?.videoIdentity ? {
      key: experiment.page.videoIdentity,
      title: experiment.page.title,
      url: experiment.page.url,
      platform: experiment.platform
    } : null),
    savedAt: new Date().toISOString()
  });
  if (!entry) throw new Error("Select a German word before saving it.");
  const { entries } = await getSavedWords();
  const updated = [entry, ...entries.filter((item) => item.normalizedWord !== entry.normalizedWord)];
  await chrome.storage.local.set({ [VOCABULARY_KEY]: updated.slice(0, 2_000) });
  return { entry, saved: true, count: updated.length };
}

async function removeSavedWord(rawWord) {
  const normalized = learning.normalizedWord(rawWord);
  const { entries } = await getSavedWords();
  const updated = entries.filter((entry) => entry.normalizedWord !== normalized);
  await chrome.storage.local.set({ [VOCABULARY_KEY]: updated });
  return { saved: false, count: updated.length };
}

async function isVocabularyWordSaved(normalized) {
  const { entries } = await getSavedWords();
  return entries.some((entry) => entry.normalizedWord === normalized);
}

function hasCompleteLiveCoverage(experiment) {
  if (!experiment?.asrSegments?.length) return false;
  const duration = Number(experiment.page?.duration) || 0;
  if (duration <= 0) return false;
  const ranges = mergeCoverageRanges(experiment.audioCoverage || []);
  return ranges.length === 1
    && ranges[0].start <= 1
    && ranges[0].end >= duration - 1;
}

async function saveTranscriptToLibrary(experiment) {
  const identity = experiment?.page?.videoIdentity
    || learning.stableVideoIdentity(experiment?.page?.url, experiment?.audioLanguage);
  const key = learning.transcriptStorageKey(identity);
  const segments = sanitizeTranscriptSegments(experiment?.asrSegments);
  if (!identity || !key || !segments.length) return null;
  const duration = Math.max(
    Number(experiment.page?.duration) || 0,
    segments.reduce((maximum, segment) => Math.max(maximum, segment.end), 0)
  );
  const now = new Date().toISOString();
  const record = {
    schemaVersion: 1,
    key,
    identity,
    title: experiment.page?.title || "Untitled video",
    url: learning.stablePageUrl(experiment.page?.url),
    platform: experiment.platform || null,
    audioLanguage: experiment.audioLanguage || "de",
    duration: round(duration),
    segmentCount: segments.length,
    sourceExperimentId: experiment.id || null,
    savedAt: now,
    updatedAt: now,
    segments
  };
  record.bytes = JSON.stringify(record).length * 2;
  if (record.bytes > TRANSCRIPT_LIBRARY_BYTES_LIMIT) {
    throw new Error("This transcript is too large for the browser-local transcript library.");
  }
  const { entries } = await getTranscriptLibrary();
  const metadata = transcriptLibraryMetadata(record);
  const updated = [metadata, ...entries.filter((entry) => entry.key !== key)]
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  const retained = [];
  let retainedBytes = 0;
  for (const entry of updated) {
    const bytes = Math.max(0, Number(entry.bytes) || 0);
    if (retained.length >= TRANSCRIPT_LIBRARY_LIMIT) continue;
    if (retainedBytes + bytes > TRANSCRIPT_LIBRARY_BYTES_LIMIT) continue;
    retained.push(entry);
    retainedBytes += bytes;
  }
  const retainedKeys = new Set(retained.map((entry) => entry.key));
  const removed = updated.filter((entry) => !retainedKeys.has(entry.key));
  if (!retainedKeys.has(key)) {
    throw new Error("This transcript is too large for the browser-local transcript library.");
  }
  if (removed.length) await chrome.storage.local.remove(removed.map((entry) => entry.key));
  await chrome.storage.local.set({
    [key]: record,
    [TRANSCRIPT_LIBRARY_INDEX_KEY]: retained
  });
  return metadata;
}

async function trySaveTranscriptToLibrary(experiment) {
  try {
    return await saveTranscriptToLibrary(experiment);
  } catch (error) {
    console.warn("Could not add the completed transcript to the reusable library", error);
    return null;
  }
}

function sanitizeTranscriptSegments(rawSegments) {
  return (Array.isArray(rawSegments) ? rawSegments : [])
    .map((segment, index) => {
      const start = Number(segment?.start);
      const end = Number(segment?.end);
      const text = String(segment?.text || "").trim().slice(0, 2_000);
      if (!Number.isFinite(start) || !Number.isFinite(end) || end < start || !text) return null;
      const words = (Array.isArray(segment.words) ? segment.words : [])
        .map((word) => ({
          text: String(word?.text || "").trim().slice(0, 100),
          start: round(Number(word?.start)),
          end: round(Number(word?.end))
        }))
        .filter((word) => word.text && Number.isFinite(word.start)
          && Number.isFinite(word.end) && word.end >= word.start);
      return {
        id: String(segment.id || `saved-${index}`),
        start: round(start),
        end: round(end),
        text,
        complete: segment.complete !== false,
        boundary: String(segment.boundary || "sentence").slice(0, 40),
        ...(words.length ? { words } : {})
      };
    })
    .filter(Boolean)
    .sort((a, b) => a.start - b.start || a.end - b.end);
}

async function getStoredTranscript(identity) {
  const key = learning.transcriptStorageKey(identity);
  if (!key) return null;
  const record = await getTranscriptLibraryRecord(key);
  return record?.identity === identity ? record : null;
}

async function getTranscriptLibraryRecord(key) {
  if (!String(key || "").startsWith("transcript-library:v1:")) return null;
  const stored = await chrome.storage.local.get(key);
  return stored[key] || null;
}

async function getTranscriptLibrary() {
  const stored = await chrome.storage.local.get(TRANSCRIPT_LIBRARY_INDEX_KEY);
  const entries = Array.isArray(stored[TRANSCRIPT_LIBRARY_INDEX_KEY])
    ? stored[TRANSCRIPT_LIBRARY_INDEX_KEY]
    : [];
  return {
    entries: entries
      .filter((entry) => String(entry?.key || "").startsWith("transcript-library:v1:"))
      .slice(0, TRANSCRIPT_LIBRARY_LIMIT)
  };
}

function transcriptLibraryMetadata(record) {
  return {
    key: record.key,
    title: record.title,
    url: record.url,
    platform: record.platform,
    audioLanguage: record.audioLanguage,
    duration: record.duration,
    segmentCount: record.segmentCount,
    bytes: record.bytes,
    updatedAt: record.updatedAt
  };
}

async function removeTranscriptLibraryEntry(key) {
  if (!String(key || "").startsWith("transcript-library:v1:")) {
    throw new Error("Invalid saved transcript key.");
  }
  const { entries } = await getTranscriptLibrary();
  await chrome.storage.local.remove(key);
  const updated = entries.filter((entry) => entry.key !== key);
  await chrome.storage.local.set({ [TRANSCRIPT_LIBRARY_INDEX_KEY]: updated });
  return { entries: updated };
}

async function ensureContentScripts(tabId) {
  const results = await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    files: ["learning-features.js", "transcript-groups.js", "content.js"]
  });
  return [...new Set(results.map((result) => result.frameId))];
}

async function findMediaTarget(tabId, frameIds) {
  const candidates = await Promise.all(frameIds.map(async (frameId) => {
    const response = await sendToFrame(tabId, frameId, { type: "GET_MEDIA_CONTEXT" });
    if (!response?.ok || !response.context) return null;
    return { frameId, context: response.context };
  }));
  return candidates
    .filter(Boolean)
    .sort((a, b) => mediaTargetScore(b.context) - mediaTargetScore(a.context))[0]
    || null;
}

function mediaTargetScore(context) {
  const area = Math.max(0, Number(context.width) * Number(context.height)) || 0;
  return (context.paused ? 0 : 1_000_000_000)
    + (context.visible ? 100_000_000 : 0)
    + (Number(context.readyState) > 0 ? 10_000_000 : 0)
    + (Number(context.currentTime) > 0 ? 1_000_000 : 0)
    + area;
}

async function ensureOffscreenDocument() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL("offscreen.html")]
  });
  if (contexts.length) return;
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["USER_MEDIA"],
    justification: "Capture the user-selected tab audio for a local transcription experiment."
  });
}

async function sendToOffscreen(message) {
  try {
    return await chrome.runtime.sendMessage(message);
  } catch {
    return null;
  }
}

async function sendToFrame(tabId, frameId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message, { frameId });
  } catch {
    return null;
  }
}

async function sendToActiveFrame(active, message) {
  return sendToFrame(active.tabId, active.mediaFrameId ?? 0, message);
}

function isActiveMediaFrame(active, tabId, frameId) {
  return Boolean(active)
    && active.tabId === tabId
    && (active.mediaFrameId ?? 0) === (frameId ?? 0);
}

function isLiveMode(active) {
  return Boolean(active) && (!active.mode || active.mode === "live");
}

async function broadcastStatus(status, error = null) {
  try {
    await chrome.runtime.sendMessage({ type: "EXPERIMENT_STATUS", status, error });
  } catch {
    // The popup is usually closed while an experiment runs.
  }
  const active = await getActive();
  if (active) await sendToActiveFrame(active, { type: "STATUS_UPDATE", status, error });
}

async function getActive() {
  const stored = await chrome.storage.session.get(ACTIVE_KEY);
  return stored[ACTIVE_KEY] || null;
}

async function setActive(active) {
  await chrome.storage.session.set({ [ACTIVE_KEY]: active });
}

async function getExperiment(id) {
  const key = `${EXPERIMENT_PREFIX}${id}`;
  const stored = await chrome.storage.local.get(key);
  return stored[key] || null;
}

async function saveExperiment(experiment) {
  const liveCoverage = audioCoverageRanges.get(experiment.id);
  if (liveCoverage) {
    experiment.audioCoverage = liveCoverage.map((range) => ({ ...range }));
  }
  await chrome.storage.local.set({
    [`${EXPERIMENT_PREFIX}${experiment.id}`]: experiment,
    [LAST_KEY]: experiment.id
  });
}

function createEpoch(mediaStart, playbackRate, reason) {
  return {
    id: crypto.randomUUID(),
    mediaStart: round(Number(mediaStart) || 0),
    playbackRate: Number(playbackRate) || 1,
    anchored: false,
    reason,
    createdAt: new Date().toISOString()
  };
}

function normalizeRuntimeSettings(settings = {}) {
  return {
    serverUrl: String(settings.serverUrl || "").trim(),
    audioLanguage: String(settings.audioLanguage || "de").trim().slice(0, 16) || "de",
    captionLanguage: String(settings.captionLanguage || "de").trim().slice(0, 16) || "de",
    collectCaptions: settings.collectCaptions !== false,
    batchModel: String(settings.batchModel || "small").slice(0, 64),
    syncOffset: normalizeSyncOffset(settings.syncOffset),
    captionPreferences: learning.normalizeCaptionPreferences(settings.captionPreferences),
    translationPreferences: learning.normalizeTranslationPreferences(
      settings.translationPreferences
    )
  };
}

function validateSettings(settings) {
  if (!settings) throw new Error("Experiment settings are missing.");
  const url = new URL(settings.serverUrl);
  if (!['ws:', 'wss:'].includes(url.protocol)) throw new Error("The server URL must use ws:// or wss://.");
  if (!['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)) {
    throw new Error("For this experiment the transcription server must run locally.");
  }
}

function identifyPlatform(url) {
  const host = new URL(url).hostname.replace(/^www\./, "");
  if (host.endsWith("youtube.com") || host === "youtu.be") return "youtube";
  return host;
}

function round(value) {
  return Math.round(value * 1000) / 1000;
}

function formatClock(seconds) {
  const wholeSeconds = Math.max(0, Math.floor(Number(seconds) || 0));
  const minutes = Math.floor(wholeSeconds / 60);
  const remainder = String(wholeSeconds % 60).padStart(2, "0");
  return `${minutes}:${remainder}`;
}

function formatMegabytes(bytes) {
  return `${(Math.max(0, Number(bytes) || 0) / (1024 * 1024)).toFixed(1)} MB`;
}

function formatTransferRate(bytesPerSecond) {
  const speed = Math.max(0, Number(bytesPerSecond) || 0);
  if (speed < 1024 * 1024) return `${(speed / 1024).toFixed(0)} KB/s`;
  return `${(speed / (1024 * 1024)).toFixed(1)} MB/s`;
}

function normalizeSyncOffset(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return 0;
  const rounded = Math.round(Math.max(-3, Math.min(3, number)) * 10) / 10;
  return Object.is(rounded, -0) ? 0 : rounded;
}

function formatEvaluationSummary(evaluation) {
  const agreement = Number(evaluation?.metrics?.wordAgreementEstimate);
  if (!Number.isFinite(agreement)) return "";
  return ` Caption agreement estimate: ${(agreement * 100).toFixed(1)}%.`;
}
